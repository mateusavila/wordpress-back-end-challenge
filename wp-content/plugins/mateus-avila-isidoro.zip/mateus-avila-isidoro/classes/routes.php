<?php
/**
 * Arquivo da classe InstallWordpressPlugin
 * 
 * PHP version 8.3.7
 * 
 * @category InstallWordpressPlugin
 * @package  Mateus Ávila Isidoro
 * @author   Mateus Ávila Isidoro <mateus@mateusavila.com.br>
 * @license  http://opensource.org/licenses/MIT MIT
 * @link     https://www.linkedin.com/in/mateusavilaisidoro
 */

namespace MateusAvila;

class RoutesWordpressPlugin
{
    public function __construct()
    {
        add_action('send_headers', [$this, 'allow_cors']);
        $this->add_default_routes();
    }

    /**
     * allow CORS
     *
     * @return void cria as rotas
     */
    public function allow_cors()
    {
        header("Access-Control-Allow-Origin: *");
    }
    
    /**
     * Define the routes of the application
     *
     * @return void cria as rotas
     */
    public function add_default_routes()
    {
        add_action('rest_api_init', function() {
            register_rest_route('api', '/login', array(
                'methods' => 'POST',
                'callback' => [$this, 'login_user']),
            );
            register_rest_route('api', '/logoff', array(
                'methods' => 'POST',
                'callback' => [$this, 'logoff_user']),
            );
            register_rest_route('api', '/favorite', array(
                'methods' => 'POST',
                'callback' => [$this, 'favorite_post']),
            );
        });   
    }

    /**
     * Make WP login
     *
     * @return void adiciona a possibilidade do usuário realizar login no WP
     */
    public function login_user(WP_REST_Request $request)
    {
        $get = file_get_contents('php://input');
        $g = json_decode($get, true);

        if(empty($g['user_login'])) {
            return wp_send_json(array(
            "title" => "Erro!",
            "text" => "É necessário preencher o username"
            ), 422);
        }

        if(empty($g['user_password'])) {
            return wp_send_json(array(
            "title" => "Erro!",
            "text" => "É necessário preencher a senha"
            ), 422);
        }

        $creds = array(
            'user_login' => $g['user_login'],
            'user_password' => $g['user_password'],
            'remember' => true
        );

        $user = wp_signon($creds, false);

        if ( is_wp_error( $user ) ) {
            return wp_send_json(array(
                'logged' => false,
                "title" => "Erro!",
                "text" => $user->get_error_message()
            ), 422);
        }

        wp_clear_auth_cookie();  
        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID);
        // return $user;
        return wp_send_json(array(
            'logged' => true,
            'user' => array(
                'id' => $user->ID,
                'name' => $user->display_name
            )
        ), 200);
    }

    /**
     * Logoff the user
     *
     * @return string with the logoff information
     */
    public function logoff_user(WP_REST_Request $request)
    {
        wp_logout();
        return wp_send_json(array(
            'logged' => false
        ), 200);
    }

    /**
     * Favorite/unfavorite a post
     *
     * @return string retorna o resultado da requisição
     */
    public function favorite_post(WP_REST_Request $request)
    {
        if (!wp_get_current_user()) {
            return wp_send_json(array(
                "title" => "Erro!",
                "text" => 'Você precisa estar logado para poder executar esta rota'
            ), 422);
        }
        
        $get = file_get_contents('php://input');
        $g = json_decode($get, true);

        if(empty($g['user_id']) || !(is_numeric($g['user_id']))) {
            return wp_send_json(array(
              'success' => false,
              "title" => "Erro!",
              "text" => "É necessário enviar a ID do usuário"
            ), 422);
        }

        if(empty($g['post_id']) || !(is_numeric($g['post_id']))) {
            return wp_send_json(array(
              'success' => false,
              "title" => "Erro!",
              "text" => "É necessário enviar a ID do POST"
            ), 422);
        }

        // verificar se existe o registro
        global $wpdb;
        $table = $wpdb->prefix."favorite";
        $user_id = (int) $g['user_id'];
        $post_id = (int) $g['post_id'];
        $results = $wpdb->get_results($wpdb->prepare("SELECT id FROM $table WHERE `post_id`=%d and `user_id`=%d", $post_id, $user_id));

        if ($results) {
            $wpdb->delete($table, array('post_id' => $post_id, 'user_id' => $user_id));
            return wp_send_json(array(
                'success' => true,
                "title" => "Sucesso!",
                "text" => "Você desfavoritou este post"
            ), 200);
        }

        $wpdb->insert($table, array('post_id' => $post_id, 'user_id' => $user_id, 'fav_date' => date('Y-m-d H:i:s')), array('%d', '%d', '%s'));
        return wp_send_json(array(
            'success' => true,
            "title" => "Sucesso!",
            "text" => "Você favoritou este post"
        ), 200);
    }
}

$app = new RoutesWordpressPlugin();